const NotFound = () => {
  return (
    <>
      <header>
        <h2>This is About</h2>
      </header>
    </>
  );
};
export default NotFound;
