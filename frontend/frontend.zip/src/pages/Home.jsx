import { useDispatch, useSelector } from "react-redux";
import styles from "./Home.module.css";
import { useEffect, useState } from "react";
import { addTodo, fetchTodos } from "../feature/todoSlice";
import Modal from "../components/Modal";
import { MdEditDocument } from "react-icons/md";

const Home = () => {
  const { todos, loading } = useSelector((state) => state.todo);
  const { user } = useSelector((state) => state.auth);
  console.log("hey", user, todos);

  const [isModalOpen, setIsModelOpen] = useState(false);
  const dispatch = useDispatch();
  const open = () => setIsModelOpen(true);
  const close = () => setIsModelOpen(false);
  useEffect(() => {
    dispatch(fetchTodos(user.id));
  }, [dispatch]);

  const submitHandler = (currData) => {
    dispatch(addTodo({ ...currData, user_id: user.id }));
  };
  return (
    <div className={styles["container"]}>
      <h2>Todo List</h2>
      <button onClick={open}>Add Todo</button>
      <Modal isOpen={isModalOpen} onClose={close} onSubmit={submitHandler} />
      <div className={styles["todo-list-container"]}>
        {todos.map((todo, index) => (
          <div key={index} className={styles["todo-list-item"]}>
            <h3>{todo.title}</h3>
            <p>{todo.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
export default Home;
