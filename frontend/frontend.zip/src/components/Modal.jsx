import { memo, useState } from "react";
import styles from "./Modal.module.css";
import reactDOM from "react-dom";
import { IoMdClose } from "react-icons/io";

const Modal = memo(({ isOpen, onClose, onSubmit }) => {
  if (!isOpen) return null;
  const [formData, setFormData] = useState({ title: "", description: "" });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({ ...prevFormData, [name]: value }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  return reactDOM.createPortal(
    <div className={styles["modal-overlay"]}>
      <div
        className={styles["modal-content"]}
        onClick={(e) => e.stopPropagation()}
      >
        <h2>Add New Todo</h2>
        <span className={styles["close"]} onClick={() => onClose()}>
          <IoMdClose />
        </span>
        <form onSubmit={handleSubmit}>
          <div className={styles["modal-group"]}>
            <label>Title</label>
            <input
              placeholder="Enter Title"
              onChange={handleInputChange}
              value={formData.title}
              required
              name="title"
            />
          </div>
          <div className={styles["modal-group"]}>
            <label>Description</label>
            <textarea
              placeholder="Enter Description"
              onChange={handleInputChange}
              value={formData.description}
              required
              name="description"
            />
          </div>
          <div className={styles["modal-buttons"]}>
            <button onClick={onSubmit}>Add Todo</button>
            {/* <button onClick={onClose}>Close</button> */}
          </div>
        </form>
      </div>
    </div>,
    document.getElementById("model-root")
  );
});
export default Modal;
